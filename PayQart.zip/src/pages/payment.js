import Left from "../component/leftSide";
import React from 'react';

import Paymentright from "../component/paymentright";

function Payment() {
  return (
    <div className="billing-page">



     <Left />

     <Paymentright />
    </div>
  );
}

export default Payment;