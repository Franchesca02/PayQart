import Left from "../component/leftSide";
import Right from "../component/rightSide";

function Home() {
  return (
    <div className="home">
     <Left/>
     <Right/>
    </div>
  );
}

export default Home;
